Credits to Xignotic for providing the base CSS folder to make my life so much easier.
Credits to the authors who did the backgrounds for the Hacknet Themes, you guys rock.

To install:

Drag the CSS folder that's inside of these folders to your DBM folder (Usually the folder is in \Steam\steamapps\common\Discord Bot Maker).
Restart DBM and the theme should be installed.
