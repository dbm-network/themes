# DBM Themes By JoKeR#0001

Here are some Themes for Discord Bot Maker! Feel free to use them in your bots. If you want to share these files, please share the URL of this GitHub page for the latest updates!

### Download
  1. Go to https://github.com/Discord-Bot-Maker-Mods/DBM-Themes/
  2. Click the green button Clone or download
  3. Choose Download ZIP
  4. Open ZIP and open the DBM-Themes-master folder

### Install
  1. After downloading, open DBM
  2. Click on Project
  3. Click on Open Actions Directory
  4. Go back to previous directory and then copy & paste all files from your wish-themes files folder and replace them

### Uninstall
  1. Only Verify your DBM in Steam.

### Modify
  1. Open DBM and Click on Project
  2. Click on Open Actions Directory
  4. Go back to previous directory and then copy & paste all files from your wish-theme and replace them

`If any mistake is found, tell us!`

This project is operated by the DBM Network (https://mythbot.tk)

### Support
  Discord: (https://discord.gg/EKtTPSr)

#### Credits to JoKeR#0001 For Building This DBM Theme
#### Credits to the authors who did the backgrounds Images and only Images Used #### in this Theme, you guys rock.
